const TelegramBot = require('node-telegram-bot-api');
const { Low, JSONFile } = require('lowdb');
const path = require('path');

// Replace this with your actual bot token
const token = process.env.BOT_TOKEN || 'YOUR_BOT_TOKEN_HERE';

// Create bot
const bot = new TelegramBot(token, { polling: true });

// Set up DB
const dbFile = path.join(__dirname, 'db.json');
const adapter = new JSONFile(dbFile);
const db = new Low(adapter);

// Init DB
async function initDB() {
  await db.read();
  db.data ||= { users: [] };
  await db.write();
}
initDB();

// Handle user messages
bot.on('message', async (msg) => {
  const userId = msg.from.id;
  await db.read();

  if (!db.data.users.includes(userId)) {
    db.data.users.push(userId);
    await db.write();
  }

  const userCount = db.data.users.length;
  bot.sendMessage(msg.chat.id, `এই বট বর্তমানে ${userCount} জন ব্যবহারকারী ব্যবহার করছে।`);
});

// /stats command
bot.onText(/\/stats/, async (msg) => {
  await db.read();
  const count = db.data.users.length;
  bot.sendMessage(msg.chat.id, `বর্তমানে ${count} জন এই বট ব্যবহার করছে।`);
});
